/*
 * periph.c
 *
 *  DO NOT ERASE ME! I AM THE MAGIC THAT MAKES CCS WORK!
 */


#include <stdio.h>
#include "usbstk5505.h"
#include "usbstk5505_i2c.h"
#include "usbstk5505_i2s.h"
#include "usbstk5505_gpio.h"
#include "main.h"

void Init_USBSTK5505( Uint32 sf, Int16 gDAC, Uint16 gADC )
{
	/* Initialize BSL */
	USBSTK5505_init( );

	/* Set A20_MODE for GPIO mode */
	CSL_FINST(CSL_SYSCTRL_REGS->EBSR, SYS_EBSR_A20_MODE, MODE1);

	/* Use GPIO to enable AIC3204 chip */
	USBSTK5505_GPIO_init();
	USBSTK5505_GPIO_setDirection(GPIO26, GPIO_OUT);
	USBSTK5505_GPIO_setOutput( GPIO26, 1 );    // Take AIC3204 chip out of reset

	/* Initialize I2C */
	USBSTK5505_I2C_init( );

	/* Initialize I2S */
	USBSTK5505_I2S_init( );

	/* Initialized AIC3204 */
	Init_AIC3204( sf, gDAC, gADC );
}

Int16 read_right(void)
{
	Int16 in[5];
	USBSTK5505_I2S_readLeft(in);
	return in[0];
}

Int16 read_left(void)
{
	Int16 in[1];
	USBSTK5505_I2S_readRight(in);
	return in[0];
}

void write_right(Int16 out)
{
	USBSTK5505_I2S_writeRight(out);
	return;
}

void write_left(Int16 out)
{
	USBSTK5505_I2S_writeLeft(out);
	return;
}
