#ifndef MAIN_H_
#define MAIN_H_

/*Math defines*/
#define PI 3.1416

/*Sampling frequency defines*/
#define SF_48KHz (Uint32)48000
#define SF_24KHz (Uint32)24000
#define SF_16KHz (Uint32)16000
#define SF_12KHz (Uint32)12000
#define SF_8KHz  (Uint32)8000

void Init_USBSTK5505(Uint32 sf,Int16 gDAC,Uint16 gADC);
Int16 read_right(void);
Int16 read_left(void);
void write_right(Int16 out);
void write_left(Int16 out);

extern void Init_AIC3204(Uint32 sf, Int16 gDAC, Uint16 gADC);

#endif /* MAIN_H_ */
