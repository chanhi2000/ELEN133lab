// program main.c

#include <stdio.h>
#include <math.h>
#include "tistdtypes.h"
#include "main.h"

/*CODEC initialization defines*/
#define GDAC 	3			// DAC gain in dB 		[-6dB to 29dB in 1dB steps]
#define GADC 	0.5			// ADC gain in dB 		[0dB to 47.5dB in 0.5dB steps]
#define SF		SF_8KHz		// sampling frequency 	[SF_8KHz,SF_12KHz,SF_16KHz,SF_24KHz,SF_48KHz]

/*User defines*/
#define BUF_SIZE	4000	// length of buffer (must be longer than longest delay)
#define GAIN		4		// gain applied to output
#define DELAY		2000	// delay size in samples
#define GFB 		0.6		// feedback gain

void main(void)
{
	Int16 buf[BUF_SIZE];
	Uint32 ind_in = BUF_SIZE;
	Uint32 ind_out = BUF_SIZE - DELAY;
	Uint32 i;

	/*Initialize buffer*/
	for(i = 0; i < BUF_SIZE; i++)
		buf[i] = 0;

	/*Initialize DSP and CODEC*/
	Init_USBSTK5505(SF, GDAC, GADC);

	/* Infinite loop */
	while(1)
	{
		if(++ind_in >= BUF_SIZE)						// circularly loop through buffer index
			ind_in -= BUF_SIZE;
		if(++ind_out >= BUF_SIZE)						// circularly loop through buffer index
			ind_out -= BUF_SIZE;

		buf[ind_in] = read_right();						// input value from codec to buffer
		buf[ind_in] += (Int16)(GFB*buf[ind_out]); 		// add to delayed output to buffer
		write_right(GAIN*buf[ind_in]);		 			// output sample to codec
	}
}
