// program main.c

#include <stdio.h>
#include <math.h>
#include "tistdtypes.h"
#include "main.h"
#include "music.h"
#include "diddly.h"

/*CODEC initialization defines*/
#define GDAC 	3					// DAC gain in dB 		[-6dB to 29dB in 1dB steps]
#define GADC 	0.5					// ADC gain in dB 		[0dB to 47.5dB in 0.5dB steps]
#define SF		SF_8KHz				// sampling frequency 	[SF_8KHz,SF_12KHz,SF_16KHz,SF_24KHz,SF_48KHz]

/*User defines*/
#define TABLE_SIZE	1024			// size of sine table
#define GAIN		10000			// gain of sine table
#define AMPLITUDE	1				// gain of output

/*Functions*/
float get_inc(float note, Uint32 sf, Uint32 tsize);

void main(void)
{
	float sine_table[TABLE_SIZE];
	Int16 i = 0;
	float ind = 0.0;
	Uint16 counter = 0;
	Uint16 selector = 0;
	Uint16 sample_dur;
	float sample_inc;

	/*Initialize sine table*/
	for(i = 0; i < TABLE_SIZE; i++)
		  sine_table[i]=GAIN*sin(2.0*PI*i/TABLE_SIZE);

	/*Initialize DSP and CODEC*/
	Init_USBSTK5505(SF, GDAC, GADC);

	sample_dur = (Uint16)(time_dur[selector]*(float)SF);
	sample_inc = get_inc(notes[selector],SF,TABLE_SIZE);

	/* Infinite loop */
	while(1)
	{
		read_right();					  									// makes loop sample at SF
		write_right((Int16)(AMPLITUDE*sine_table[(Uint16)(round(ind))])); 	// output sample to codec
		ind += sample_inc;													// increment the index
		if ((Uint16)round(ind) >= TABLE_SIZE)  		  						// reset index if end of table
			ind -= (float)TABLE_SIZE;

		if (++counter > sample_dur)											// update tone and duration if end of current note
		{
			if (++selector >= SONGLENG)
				selector = 0;
			sample_dur = (Uint16)(time_dur[selector]*SF);					// update duration
			sample_inc = get_inc(notes[selector],SF,TABLE_SIZE);			// update tone
			counter = 0;
		}
	}
}

float get_inc(float note, Uint32 sf, Uint32 tsize)
{
	/*
	 * 		ENTER YOUR CODE HERE, USE PRELAB AS GUIDE!!!
	 */
}
