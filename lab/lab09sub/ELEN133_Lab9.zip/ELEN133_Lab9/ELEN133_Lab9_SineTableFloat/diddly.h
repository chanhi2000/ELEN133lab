/*
 * diddly.h
 */
 
#include "music.h"

#define BPM			78		// beats per minute
#define SONGLENG	28		// number of notes + rests in song

float time_dur[SONGLENG] = {
	QDN, EN,   HN, QN,  HN, QN, QN,   EN, EN, QN, QN,  HN, QN, HDN,  QDN, EN,   QN,  QN, QN, QDN, EN,   QN, QDN, EN,   QN, QDN, EN,   QN
};

float notes[SONGLENG] = {
	B2,  REST, B2, Fs3, A3, B3, REST, A3, B3, A3, Fs3, A3, B3, REST, Fs3, REST, Fs3, E3, D3, E3,  REST, E3, G2,  REST, G2, A2,  REST, A2
};
 
 
