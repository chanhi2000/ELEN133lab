// program main.c

#include <stdio.h>
#include <math.h>
#include "tistdtypes.h"
#include "main.h"

/*CODEC initialization defines*/
#define GDAC 	3					// DAC gain in dB 		[-6dB to 29dB in 1dB steps]
#define GADC 	0.5					// ADC gain in dB 		[0dB to 47.5dB in 0.5dB steps]
#define SF		SF_8KHz				// sampling frequency 	[SF_8KHz,SF_12KHz,SF_16KHz,SF_24KHz,SF_48KHz]

/*User defines*/
#define TABLE_SIZE	32				// size of sine table
#define GAIN		10000			// gain of sine table
#define TIME_INT	2				// time interval per increment
#define INC_MAX		4				// maximum increment value

void main(void)
{
	float sine_table[TABLE_SIZE];
	Uint16 i = 0;
	Uint16 inc = 1;
	Uint16 counter = 0;
	Uint16 sample_int = (Uint16)(TIME_INT*SF);

	/*Initialize sine table*/
	for(i = 0; i < TABLE_SIZE; i++)
		  sine_table[i]=sin(2.0*PI*i/TABLE_SIZE);

	/*Initialize DSP and CODEC*/
	Init_USBSTK5505(SF, GDAC, GADC);

	/* Infinite loop */
	while(1)
	{
		read_right();							  	// makes loop sample at SF
		write_right((Int16)(GAIN*sine_table[i])); 	// output sample to codec
		i += inc;									// increment the index
		if (i >= TABLE_SIZE)  		  				// reset index if end of table
			i -= TABLE_SIZE;
		if (++counter > sample_int)					// update increment if end of interval
		{
			counter = 0;
			if (++inc > INC_MAX)
				inc = 1;
		}
	}
}
